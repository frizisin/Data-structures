﻿#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    cout << "ФИО: Тимошинов Александр Александрович" << endl;
    cout << "Группа: 090304-РПИа-о25" << endl;

    int N;
    cin >> N;

    if (N % 2 == 0 || N % 5 == 0) {
        cout << "NO";
        return 0;
    }

    vector<bool> used(N, false);

    int remainder = 1 % N;
    string result = "1";

    while (remainder != 0) {
        if (used[remainder]) {
            cout << "NO";
            return 0;
        }

        used[remainder] = true;
        remainder = (remainder * 10 + 1) % N;
        result += '1';
    }

    cout << result;

    return 0;
}